class TestA(Exception):
    pass


class TestB(TestA):
    pass