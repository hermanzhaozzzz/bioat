from biat._version import version as __version__
from biat._version import author as __author__
from biat._version import email as __email__
from pysam import __version__ as __pysam_version__
from pysamstats import __version__ as __pysamstats_version__