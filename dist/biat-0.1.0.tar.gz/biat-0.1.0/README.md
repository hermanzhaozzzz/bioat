# BioinformaticAnalysisTools

A bioinformatic python toolkit accelerated with rust!

- Author: Hua-nan ZHAO @Tsinghua University
- E-Mail: hermanzhaozzzz@gmail.com

## usage

```python
import biat
```

